
/*
 * Copyright 1986 by Larry Campbell, 73 Concord Street, Maynard MA 01754 USA
 * (maynard!campbell).  You may freely copy, use, and distribute this software
 * subject to the following restrictions:
 *
 *  1)	You may not charge money for it.
 *  2)	You may not remove or alter this copyright notice.
 *  3)	You may not claim you wrote it.
 *  4)	If you make improvements (or other changes), you are requested
 *	to send them to me, so there's a focal point for distributing
 *	improved versions.
 *
 * John Chmielewski (tesla!jlc until 9/1/86, then rogue!jlc) assisted
 * by doing the System V port and adding some nice features.  Thanks!
 */

 /* Changes for the CM11A made by Daniel Suthers, dbs@tanj.com */

#include <stdio.h>
#include <time.h>
#include "x10.h"
#include <unistd.h>
#ifdef SYSV
#include <sys/types.h>
#endif

#include <sys/param.h>
#ifdef BEFORE
#include <sys/filsys.h>
#endif
#include "x10.h"


extern void error();

extern int
 Idays, Ihours, Iminutes;

/* ARGSUSED */

int c_date(argc, argv)
char *argv[];
{
    int  today;
    struct tm *tp;
    char RCSID[]= "@(#) $Id: date.c,v 1.9 2003/03/17 01:40:32 dbs Exp dbs $\n";
    extern int usage(), get_status(), dowX2U();
    time_t now;

    display(RCSID);
    if (argc != 2)
	usage(E_2MANY);
    time(&now);
    tp = localtime(&now);

    if( get_status() < 1 )
        error(" No reponse from CM11A.  Program exiting");
    today = dowX2U(Idays);
#ifndef POSIX
    while (tp->tm_wday % 7 != today)
	tp->tm_wday++, tp->tm_mday++;
#endif

#ifdef VENIX
    (void) printf("%2d%02d%02d%02d%02d\n",
	     tp->tm_year % 100, tp->tm_mon + 1, tp->tm_mday, Ihours, Iminutes);
#else
    (void) printf("%02d%02d%02d%02d%02d\n",
	     tp->tm_mon + 1, tp->tm_mday, Ihours, Iminutes, tp->tm_year % 100);
#endif
    return(0);
}
