/*
 * Copyright 1986 by Larry Campbell, 73 Concord Street, Maynard MA 01754 USA
 * (maynard!campbell).  You may freely copy, use, and distribute this software
 * subject to the following restrictions:
 *
 *  1)	You may not charge money for it.
 *  2)	You may not remove or alter this copyright notice.
 *  3)	You may not claim you wrote it.
 *  4)	If you make improvements (or other changes), you are requested
 *	to send them to me, so there's a focal point for distributing
 *	improved versions.
 *
 * John Chmielewski (tesla!jlc until 9/1/86, then rogue!jlc) assisted
 * by doing the System V port and adding some nice features.  Thanks!
 */
/*
 * updated by Daniel Suthers, dbs@tanj.com 1996 -- 2000 
 */

#include <stdio.h>
#include "x10.h"
#include <limits.h>

char *E_2MANY = EM_2MANY;
char *E_INVCN = EM_INVCN;
char *E_WNA = EM_WNA;
char *E_NMA = EM_NMA;
char *E_NOCMD = EM_NOCMD;

extern char writelock[PATH_MAX];

void exit();

int usage(s)
char *s;
{

    char RCSID[]= "@(#) $Id: message.c,v 1.13 2003/03/17 01:40:32 dbs Exp dbs $\n";

/*
 * Don't combine the two calls to fputs or my compiler will
 * gag with "token too long"
 */

    display(RCSID);

    if( s != NULL )
    (void) fprintf(stderr, "Command error: %s\n", s);
    (void) fputs("Usage:\n\
 heyu address ann             Send an address code (useful for programming\n\
                              scene setting switches). Also see function.\n\
 heyu date                    returns date in date(1) input format\n", stderr);
    (void) fputs("\
 heyu erase                   Zeroes EEPROM, eraseing all events and macros\n\
 heyu function ann on|off     send a function code without an address\n\
 heyu help                    prints this message and exits\n\
 heyu info                    gets current settings\n\
 heyu monitor                 monitor X10 activity (end with <BREAK>)\n\
 heyu helper monitor          monitor X10 activity and respond to it\n\
 heyu preset ann vv           sets unit to level vv for next dim/bright\n\
 heyu reset  [housecode]      reset interface to 'A' or specified housecode\n\
 heyu setclock                sets X10 clock to system clock\n\
 heyu status ann[,nn...]      returns status of smart modules (rr501...)\n\
 heyu stop                    stops the current relay daemon\n\
 heyu turn ann[,nn...] on|off|up|down [vv]\n\
                              changes state of housecode a, unit nn by vv\n\
 heyu upload [check]          Uploads schedule to CM11a or checks the file\n\
 heyu version                 prints the version and exits\n\
", stderr);
    (void) fputs("Verbose mode is enabled if the first parameter is -v\n",
            stderr);
    exit(1);
}

void error(s)
char *s;
{
    extern void quit();
    extern int munlock();
    extern int port_locked;

    (void) fprintf(stderr, "HEYU: %s\n", s);
    if( port_locked == 1 )
        munlock( writelock );

    quit();
}
